---
title: "Your First Post"
date: 2025-04-28T00:00:00Z
draft: false
---
This is your very first blog post with Hugo on Methodical Cloud!